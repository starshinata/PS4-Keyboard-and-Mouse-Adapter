**Run** 
```
RemotePlayInstaller_8.0.0.14120_Win32.msi
```

**DO NOT RUN**
* RemotePlayInstaller_8.0.0.14120_Win32.exe
* RemotePlayInstaller_8.0.0.14120_Win32.isc