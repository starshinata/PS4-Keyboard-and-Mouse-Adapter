**Run** 
```
RemotePlayInstaller_5.5.0.08250_Win32.msi
```

**DO NOT RUN**
* RemotePlayInstaller.exe
* RemotePlayInstaller_5.5.0.08250_Win32.isc