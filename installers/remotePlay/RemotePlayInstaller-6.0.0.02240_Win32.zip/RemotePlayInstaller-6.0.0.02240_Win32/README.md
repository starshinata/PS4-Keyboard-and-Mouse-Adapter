**Run** 
```
RemotePlayInstaller_6.0.0.02240_Win32.msi
```

**DO NOT RUN**
* RemotePlayInstaller.exe
* RemotePlayInstaller_6.0.0.02240_Win32.isc